'use strict';

/**
 * @ngdoc service
 * @name angularYeoApp.myService
 * @description
 * # myService
 * Service in the angularYeoApp.
 */
angular.module('angularYeoApp')
  .service('myService', function () {
    // AngularJS will instantiate a singleton by calling "new" on this function
  });
