'use strict';

/**
 * @ngdoc function
 * @name angularYeoApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the angularYeoApp
 */
angular.module('angularYeoApp')
  .controller('MainCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
