'use strict';

/**
 * @ngdoc function
 * @name angularYeoApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the angularYeoApp
 */
angular.module('angularYeoApp')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
